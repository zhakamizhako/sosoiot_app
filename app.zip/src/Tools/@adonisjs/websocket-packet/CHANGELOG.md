<a name="1.0.6"></a>
## [1.0.6](https://github.com/adonisjs/adonis-websocket-packet/compare/v1.0.5...v1.0.6) (2018-03-14)


### Bug Fixes

* **makeEvent:** allow event body to empty ([5dbbff7](https://github.com/adonisjs/adonis-websocket-packet/commit/5dbbff7))



<a name="1.0.5"></a>
## [1.0.5](https://github.com/adonisjs/adonis-websocket-packet/compare/v1.0.4...v1.0.5) (2018-03-11)



<a name="1.0.4"></a>
## [1.0.4](https://github.com/adonisjs/adonis-websocket-packet/compare/v1.0.3...v1.0.4) (2018-03-06)



<a name="1.0.3"></a>
## [1.0.3](https://github.com/adonisjs/adonis-websocket-packet/compare/v1.0.2...v1.0.3) (2018-02-27)


### Bug Fixes

* **test:** use node package over umd ([d28d933](https://github.com/adonisjs/adonis-websocket-packet/commit/d28d933))



<a name="1.0.2"></a>
## [1.0.2](https://github.com/adonisjs/adonis-websocket-packet/compare/v1.0.1...v1.0.2) (2018-02-25)



<a name="1.0.1"></a>
## [1.0.1](https://github.com/adonisjs/adonis-websocket-packet/compare/v1.0.0...v1.0.1) (2018-02-20)


### Bug Fixes

* **test:** generate .nyc_output for coverage ([d3ed7ad](https://github.com/adonisjs/adonis-websocket-packet/commit/d3ed7ad))



<a name="1.0.0"></a>
# 1.0.0 (2018-02-20)


### Features

* initial commit ([b3f2bb0](https://github.com/adonisjs/adonis-websocket-packet/commit/b3f2bb0))



