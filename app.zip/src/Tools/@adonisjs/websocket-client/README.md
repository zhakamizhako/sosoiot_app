<h1 align="center">Websocket Client</h1>

<div align="center">🚀 (4KB gzipped)</div>
<div align="center">
  <strong>Websocket client for AdonisJs.</strong>
  <p>This repo contains a simple to use Jabascript client to connect with the AdonisJs websocket server.</p>
</div>

<br />

<div align="center">
  <a href="https://travis-ci.org/adonisjs/adonis-websocket-client">
    <img src="https://img.shields.io/travis/adonisjs/adonis-websocket-client.svg?style=for-the-badge" alt="Travis" />
  </a>
</div>

<br />

<div align="center">
  <a href="https://saucelabs.com/beta/builds/f55d3f5a269840da8603c39b9412e3fe"><img src="https://saucelabs.com/browser-matrix/amanvirk.svg" alt="Browser Matrix"></a>
</div>

<br />

<div align="center">
  <h3>
    <a href="https://adonisjs.com/docs/websocket">
      Official Docs
    </a>
    <span> | </span>
    <a href="https://github.com/adonisjs/adonis-websocket-vue">
      Vue Plugin
    </a>
  </h3>
</div>

<div align="center">
  <sub>Used by adonisjs.com. Built with ❤︎ by <a href="https://github.com/thetutlage">Harminder Virk</a>
</div>
