<a name="1.0.9"></a>
## [1.0.9](https://github.com/adonisjs/adonis-websocket-client/compare/v1.0.8...v1.0.9) (2018-03-21)


### Bug Fixes

* **connection:** use location.host over hostname ([4a5367d](https://github.com/adonisjs/adonis-websocket-client/commit/4a5367d))



<a name="1.0.8"></a>
## [1.0.8](https://github.com/adonisjs/adonis-websocket-client/compare/v1.0.7...v1.0.8) (2018-03-21)


### Bug Fixes

* **lint:** fix linter issue ([1cc5c2d](https://github.com/adonisjs/adonis-websocket-client/commit/1cc5c2d))



<a name="1.0.7"></a>
## [1.0.7](https://github.com/adonisjs/adonis-websocket-client/compare/v1.0.6...v1.0.7) (2018-03-21)


### Features

* **Connection:** auto detect url when not defined ([4f958e4](https://github.com/adonisjs/adonis-websocket-client/commit/4f958e4))



<a name="1.0.6"></a>
## [1.0.6](https://github.com/adonisjs/adonis-websocket-client/compare/v1.0.5...v1.0.6) (2018-03-18)


### Features

* **connection:** add login helper methods ([964c648](https://github.com/adonisjs/adonis-websocket-client/commit/964c648))
* **saucelabs:** wire up saucelabs tests ([722114e](https://github.com/adonisjs/adonis-websocket-client/commit/722114e))



<a name="1.0.5"></a>
## [1.0.5](https://github.com/adonisjs/adonis-websocket-client/compare/v1.0.4...v1.0.5) (2018-03-16)



<a name="1.0.4"></a>
## [1.0.4](https://github.com/adonisjs/adonis-websocket-client/compare/v1.0.0...v1.0.4) (2018-03-16)


### Bug Fixes

* **package:** update query-string to version 6.0.0 ([3d95855](https://github.com/adonisjs/adonis-websocket-client/commit/3d95855))


### Features

* **socket:** pass socket ref to ready event ([d2be22f](https://github.com/adonisjs/adonis-websocket-client/commit/d2be22f))



<a name="1.0.0"></a>
# 1.0.0 (2018-03-13)


### Features

* re-write for 4.0 ([18a8756](https://github.com/adonisjs/adonis-websocket-client/commit/18a8756))



